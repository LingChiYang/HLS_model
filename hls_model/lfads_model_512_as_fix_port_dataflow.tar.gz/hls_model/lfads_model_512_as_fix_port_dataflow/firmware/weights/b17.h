//Numpy array shape [49]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 49

#ifndef B17_H_
#define B17_H_

#ifndef __SYNTHESIS__
bias17_t b17[49];
#else
bias17_t b17[49] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
